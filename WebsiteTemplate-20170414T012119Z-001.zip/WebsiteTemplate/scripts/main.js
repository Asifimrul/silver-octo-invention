// JavaScript Document





function testAlert(alert) {
    $('#for_testing').css('display', 'block');
    $('#for_testing').append(alert);
}